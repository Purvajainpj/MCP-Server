import streamlit as st
import asyncio
import os
from typing import Optional

from agents import Agent, OpenAIChatCompletionsModel, Runner, set_tracing_disabled
from agents.mcp import MCPServer, MCPServerSse, MCPServerSseParams
from dotenv import load_dotenv
from openai import AsyncAzureOpenAI


def get_azure_open_ai_client():
    """
    Creates and returns Azure OpenAI client instance.
    
    Returns:
        AsyncAzureOpenAI: Configured Azure OpenAI client
    """
    load_dotenv()
    
    return AsyncAzureOpenAI(
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    )


async def get_agent_response(message: str) -> str:
    """
    Process user message through the MCP agent and return response.
    
    Args:
        message: User input message
        
    Returns:
        str: Agent's response
    """
    try:
        async with MCPServerSse(
            params=MCPServerSseParams(
                url="http://127.0.0.1:8000/sse",
                headers={
                    "Accept": "text/event-stream",
                    "Cache-Control": "no-cache",
                    "User-Agent": "MCP-Client/1.0",
                    "ngrok-skip-browser-warning": "true",
                    "Content-Type": "application/json"
                },
                timeout=60.0,
                sse_read_timeout=60.0
            ),
            name="Weather Server",
        ) as server:
            
            azure_open_ai_client = get_azure_open_ai_client()
            set_tracing_disabled(disabled=True)

            agent = Agent(
                name="Assistant",
                instructions="Use the weather tools to get current weather information for cities. Help with web browsing and data analysis tasks as needed.",
                model=OpenAIChatCompletionsModel(
                    model=os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME"), 
                    openai_client=azure_open_ai_client
                ),
                mcp_servers=[server],
            )

            result = await Runner.run(starting_agent=agent, input=message)
            return result.final_output
            
    except Exception as e:
        return f"Error: {str(e)}"


def run_async_function(coroutine):
    """
    Helper function to run async functions in Streamlit.
    """
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    
    return loop.run_until_complete(coroutine)


# Streamlit UI Configuration
st.set_page_config(
    page_title="MCP Assistant",
    page_icon="🤖",
    layout="wide"
)

# Main UI
st.title("🤖 MCP Assistant")
st.markdown("*Powered by Azure OpenAI and MCP Server*")

# Initialize chat history
if "messages" not in st.session_state:
    st.session_state.messages = []
    
# Sidebar for configuration and info
with st.sidebar:
    st.header("ℹ️ About")
    st.markdown("""
    This chatbot connects to an MCP (Model Context Protocol) server to provide:
    - 🌤️ Weather information
    - 🌐 Web browsing capabilities  
    - 📊 Data analysis features
    
    **Sample questions:**
    - "What's the weather in New York?"
    - "Tell me about today's featured article on Wikipedia"
    - "What's the wind speed in California in general ?"
    - "Tell me about delhi from Wikipedia and its weather forecast for today. Also, let me know about today's petrol price there.
    - "what can you help me with?" 
    - "Display customers who registered this year?"                     
    """)
    
    # Connection status
    st.header("🔗 Connection")
    if st.button("Test MCP Connection"):
        with st.spinner("Testing connection..."):
            try:
                test_response = run_async_function(get_agent_response("Hello"))
                if "Error:" not in test_response:
                    st.success("✅ MCP Server connected!")
                else:
                    st.error("❌ Connection failed")
                    st.error(test_response)
            except Exception as e:
                st.error(f"❌ Connection error: {str(e)}")
    # Clear chat history button
    if st.session_state.messages:
        if st.button("🗑️ Clear Chat History", type="secondary"):
            st.session_state.messages = []
            st.rerun()

# col,_=st.columns([10,1])
container=st.container(height=700,border=True)
with container:

    # Display chat messages from history
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

# Chat input
if prompt := st.chat_input("Ask me about weather, browse the web, or analyze data..."):
    # Add user message to chat history
    st.session_state.messages.append({"role": "user", "content": prompt})
    
    # Display user message
    with container:
        with st.chat_message("user"):
            st.markdown(prompt)

        # Get assistant response
        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                try:
                    response = run_async_function(get_agent_response(prompt))
                    st.markdown(response)
                    
                    # Add assistant response to chat history
                    st.session_state.messages.append({"role": "assistant", "content": response})
                    
                except Exception as e:
                    error_msg = f"Sorry, I encountered an error: {str(e)}"
                    st.error(error_msg)
                    st.session_state.messages.append({"role": "assistant", "content": error_msg})

# col,_=st.columns([10,1])
# with st.container(height=50):
#     # Footer
#     st.markdown("---")
#     st.markdown(
#         "<div style='text-align: center; color: #666; font-size: 0.8em;'>"
#         "MCP Weather Assistant | Built with Streamlit & Azure OpenAI"
#         "</div>", 
#         unsafe_allow_html=True
#     )