import asyncio
import os
import shutil

from agents import Agent, OpenAIChatCompletionsModel, Runner, set_tracing_disabled
from agents.mcp import MCPServer, MCPServerSse,MCPServerSseParams
from dotenv import load_dotenv
from openai import AsyncAzureOpenAI

async def main():
    async with MCPServerSse(
        params=MCPServerSseParams(
            url="https://815b-34-86-32-141.ngrok-free.app/sse",  # Make sure this is correct
            headers={
                "Accept": "text/event-stream",
                "Cache-Control": "no-cache",
                "User-Agent": "MCP-Client/1.0",
                "ngrok-skip-browser-warning": "true"  # Add this!
            },
            timeout=30.0,  # Increase timeout
            sse_read_timeout=30.0
        ),
        name="Weather Server",
    ) as server:
        # First try the test tool
        result = await server.call_tool("get_weather", {})
        print(f"Test result: {result}")
        
        # Then try weather
        weather_result = await server.call_tool("get_weather", {"city": "London"})
        print(f"Weather result: {weather_result}")

if __name__ == "__main__":
    asyncio.run(main())