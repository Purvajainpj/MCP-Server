#!/usr/bin/env python3

import asyncio
import json
from typing import Any, Sequence
import httpx
from urllib.parse import quote, urljoin
from bs4 import BeautifulSoup

from mcp.server.fastmcp import FastMCP

# Initialize FastMCP server
mcp = FastMCP("Search Server")

@mcp.tool()
async def internet_search(query: str, max_results: int = 10) -> dict[str, Any]:
    """
    Search the internet using DuckDuckGo Instant Answer API
    
    Args:
        query: Search query string
        max_results: Maximum number of results to return (default: 10)
    
    Returns:
        Dictionary containing search results
    """
    try:
        # Use DuckDuckGo's HTML search (no API key required)
        search_url = f"https://html.duckduckgo.com/html/?q={quote(query)}"
        
        async with httpx.AsyncClient() as client:
            response = await client.get(
                search_url,
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
                },
                timeout=10.0
            )
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            results = []
            
            # Parse search results
            for result_div in soup.find_all('div', class_='result')[:max_results]:
                title_elem = result_div.find('a', class_='result__a')
                snippet_elem = result_div.find('a', class_='result__snippet')
                
                if title_elem:
                    title = title_elem.get_text(strip=True)
                    url = title_elem.get('href', '')
                    snippet = snippet_elem.get_text(strip=True) if snippet_elem else ""
                    
                    results.append({
                        "title": title,
                        "url": url,
                        "snippet": snippet
                    })
            
            return {
                "query": query,
                "results_count": len(results),
                "results": results
            }
            
    except Exception as e:
        return {
            "error": f"Search failed: {str(e)}",
            "query": query,
            "results": []
        }

@mcp.tool()
async def website_search(site_url: str, query: str, max_results: int = 10) -> dict[str, Any]:
    """
    Search within a specific website using site-restricted search
    
    Args:
        site_url: Target website URL (e.g., "example.com")
        query: Search query string
        max_results: Maximum number of results to return (default: 10)
    
    Returns:
        Dictionary containing search results from the specified site
    """
    try:
        # Clean site URL
        site_url = site_url.replace("http://", "").replace("https://", "").replace("www.", "")
        
        # Create site-restricted search query
        site_query = f"site:{site_url} {query}"
        search_url = f"https://html.duckduckgo.com/html/?q={quote(site_query)}"
        
        async with httpx.AsyncClient() as client:
            response = await client.get(
                search_url,
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
                },
                timeout=10.0
            )
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            results = []
            
            # Parse search results
            for result_div in soup.find_all('div', class_='result')[:max_results]:
                title_elem = result_div.find('a', class_='result__a')
                snippet_elem = result_div.find('a', class_='result__snippet')
                
                if title_elem:
                    title = title_elem.get_text(strip=True)
                    url = title_elem.get('href', '')
                    snippet = snippet_elem.get_text(strip=True) if snippet_elem else ""
                    
                    results.append({
                        "title": title,
                        "url": url,
                        "snippet": snippet
                    })
            
            return {
                "site": site_url,
                "query": query,
                "results_count": len(results),
                "results": results
            }
            
    except Exception as e:
        return {
            "error": f"Website search failed: {str(e)}",
            "site": site_url,
            "query": query,
            "results": []
        }

@mcp.tool()
async def fetch_page_content(url: str) -> dict[str, Any]:
    """
    Fetch and extract text content from a webpage
    
    Args:
        url: URL of the webpage to fetch
    
    Returns:
        Dictionary containing page title and text content
    """
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
                },
                timeout=15.0,
                follow_redirects=True
            )
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Extract title
            title = soup.find('title')
            title_text = title.get_text(strip=True) if title else "No title"
            
            # Remove script and style elements
            for script in soup(["script", "style"]):
                script.decompose()
            
            # Extract text content
            text_content = soup.get_text(separator=' ', strip=True)
            
            return {
                "url": url,
                "title": title_text,
                "content": text_content[:5000],  # Limit to first 5000 chars
                "content_length": len(text_content)
            }
            
    except Exception as e:
        return {
            "error": f"Failed to fetch page: {str(e)}",
            "url": url
        }

if __name__ == "__main__":
    # Run the MCP server
    mcp.run(transport="sse")