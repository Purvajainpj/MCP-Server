import streamlit as st
import asyncio
import os
import time
from typing import Optional, List, Dict
from datetime import datetime

from agents import Agent, OpenAIChatCompletionsModel, Runner, set_tracing_disabled
from agents.mcp import MCPServer, MCPServerSse, MCPServerSseParams
from dotenv import load_dotenv
from openai import AsyncAzureOpenAI


def get_azure_open_ai_client():
    """
    Creates and returns Azure OpenAI client instance.
    
    Returns:
        AsyncAzureOpenAI: Configured Azure OpenAI client
    """
    load_dotenv()
    
    return AsyncAzureOpenAI(
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    )


class ActivityMonitor:
    """Monitor and track agent activities for UI display"""
    
    def __init__(self):
        self.activities = []
        self.current_activity = None
    
    def add_activity(self, activity_type: str, description: str, status: str = "running"):
        """Add a new activity to the monitor"""
        activity = {
            "type": activity_type,
            "description": description,
            "status": status,
            "timestamp": datetime.now().strftime("%H:%M:%S"),
            "id": len(self.activities)
        }
        self.activities.append(activity)
        self.current_activity = activity
        return activity
    
    def update_activity(self, activity_id: int, status: str, result: str = ""):
        """Update an existing activity"""
        if activity_id < len(self.activities):
            self.activities[activity_id]["status"] = status
            if result:
                self.activities[activity_id]["result"] = result
    
    def get_recent_activities(self, limit: int = 5) -> List[Dict]:
        """Get recent activities for display"""
        return self.activities[-limit:] if self.activities else []
    
    def clear(self):
        """Clear all activities"""
        self.activities = []
        self.current_activity = None


def display_activity_monitor(monitor: ActivityMonitor):
    """Display the activity monitor widget - This function is now unused but kept for reference"""
    pass


async def get_agent_response(message: str, monitor: ActivityMonitor) -> str:
    """
    Process user message through the MCP agent and return response.
    
    Args:
        message: User input message
        
    Returns:
        str: Agent's response
    """
    try:
        async with MCPServerSse(
            params=MCPServerSseParams(
                url="http://127.0.0.1:8000/sse",
                headers={
                    "Accept": "text/event-stream",
                    "Cache-Control": "no-cache",
                    "User-Agent": "MCP-Client/1.0",
                    "ngrok-skip-browser-warning": "true",
                    "Content-Type": "application/json"
                },
                timeout=60.0,
                sse_read_timeout=60.0
            ),
            name="Weather Server",
        ) as server:
            
            azure_open_ai_client = get_azure_open_ai_client()
            set_tracing_disabled(disabled=True)

            agent = Agent(
                name="Assistant",
                instructions="Use the weather tools to get current weather information for cities. Help with web browsing and data analysis tasks as needed.",
                model=OpenAIChatCompletionsModel(
                    model=os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME"), 
                    openai_client=azure_open_ai_client
                ),
                mcp_servers=[server],
            )

            result = await Runner.run(starting_agent=agent, input=message)
            return result.final_output
            
    except Exception as e:
        return f"Error: {str(e)}"


def run_async_function(coroutine):
    """
    Helper function to run async functions in Streamlit.
    """
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    
    return loop.run_until_complete(coroutine)


# Streamlit UI Configuration
st.set_page_config(
    page_title="MCP Weather Assistant",
    page_icon="🤖",
    layout="wide"
)

# Main UI
st.title("🤖 MCP Weather Assistant")
st.markdown("*Powered by Azure OpenAI and MCP Server*")

# Sidebar for configuration and info
with st.sidebar:
    st.header("ℹ️ About")
    st.markdown("""
    This chatbot connects to an MCP (Model Context Protocol) server to provide:
    - 🌤️ Weather information
    - 🌐 Web browsing capabilities  
    - 📊 Data analysis features
    
    **Sample questions:**
    - "What's the weather in New York?"
    - "Tell me about today's featured article on Wikipedia"
    - "What's the wind speed in California?"
    """)
    
    # Connection status
    st.header("🔗 Connection")
    if st.button("Test MCP Connection"):
        with st.spinner("Testing connection..."):
            try:
                # Add a test activity to demonstrate the monitor
                st.session_state.activity_monitor.add_activity("🧪 Test", "Testing MCP connection", "running")
                st.rerun()  # Show the test activity immediately
                
                test_response = run_async_function(get_agent_response("Hello", st.session_state.activity_monitor))
                if "Error:" not in test_response:
                    st.success("✅ MCP Server connected!")
                else:
                    st.error("❌ Connection failed")
                    st.error(test_response)
            except Exception as e:
                st.error(f"❌ Connection error: {str(e)}")
    
    # Activity Monitor Controls
    st.header("📊 Activity Monitor")
    if st.button("Clear Activity History"):
        st.session_state.activity_monitor.clear()
        st.rerun()
    
    # Add a demo button to test the monitor
    if st.button("🎯 Demo Activity Monitor"):
        monitor = st.session_state.activity_monitor
        monitor.add_activity("🎭 Demo", "Demonstrating activity monitor", "completed")
        monitor.add_activity("🔧 System", "Testing visual elements", "running")
        monitor.add_activity("✨ UI", "Updating interface", "completed")
        st.rerun()

# Initialize chat history and activity monitor
if "messages" not in st.session_state:
    st.session_state.messages = []

if "activity_monitor" not in st.session_state:
    st.session_state.activity_monitor = ActivityMonitor()

# Activity Monitor Widget - Always show this section
st.subheader("🔍 Agent Activity Monitor")

# Create a container for the activity monitor
activity_container = st.container()

# Show activity monitor (even if empty)
with activity_container:
    recent_activities = st.session_state.activity_monitor.get_recent_activities()
    
    if recent_activities:
        for activity in reversed(recent_activities):  # Show most recent first
            icon = "🔄" if activity["status"] == "running" else "✅" if activity["status"] == "completed" else "❌"
            status_color = "orange" if activity["status"] == "running" else "green" if activity["status"] == "completed" else "red"
            
            col1, col2, col3 = st.columns([1, 6, 2])
            with col1:
                st.markdown(f"<div style='font-size: 1.2em;'>{icon}</div>", unsafe_allow_html=True)
            with col2:
                st.markdown(f"**{activity['type']}**: {activity['description']}")
                if activity.get("result"):
                    st.markdown(f"<small style='color: gray;'>{activity['result']}</small>", unsafe_allow_html=True)
            with col3:
                st.markdown(f"<span style='color: {status_color}; font-size: 0.8em;'>{activity['timestamp']}</span>", unsafe_allow_html=True)
            
            if activity != recent_activities[0]:
                st.divider()
    else:
        st.info("💤 No recent activity. Start a conversation to see agent activities!")

st.divider()  # Separate monitor from chat

# Display chat messages from history
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# Chat input
if prompt := st.chat_input("Ask me about weather, browse the web, or analyze data..."):
    # Add user message to chat history
    st.session_state.messages.append({"role": "user", "content": prompt})
    
    # Display user message
    with st.chat_message("user"):
        st.markdown(prompt)

    # Get assistant response
    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            try:
                response = run_async_function(get_agent_response(prompt, st.session_state.activity_monitor))
                st.markdown(response)
                
                # Add assistant response to chat history
                st.session_state.messages.append({"role": "assistant", "content": response})
                
                # Rerun to update the activity monitor
                st.rerun()
                
            except Exception as e:
                error_msg = f"Sorry, I encountered an error: {str(e)}"
                st.error(error_msg)
                st.session_state.messages.append({"role": "assistant", "content": error_msg})
                st.rerun()

# Clear chat history button
if st.session_state.messages:
    col1, col2 = st.columns(2)
    with col1:
        if st.button("🗑️ Clear Chat History", type="secondary"):
            st.session_state.messages = []
            st.rerun()
    with col2:
        if st.button("🧹 Clear Activity Monitor", type="secondary"):
            st.session_state.activity_monitor.clear()
            st.rerun()

# Footer
st.markdown("---")
st.markdown(
    "<div style='text-align: center; color: #666; font-size: 0.8em;'>"
    "MCP Weather Assistant | Built with Streamlit & Azure OpenAI"
    "</div>", 
    unsafe_allow_html=True
)