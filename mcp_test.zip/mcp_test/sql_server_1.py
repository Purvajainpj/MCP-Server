from fastmcp import FastMCP
import mysql.connector
import mysql
import json
import logging
from typing import Optional

class MySQLCRUDManager:
    """MySQL CRUD operations manager for MCP server"""
    from fastmcp import FastMCP
    import mysql.connector
    import mysql
    import json
    import logging
    from typing import Optional
    
    def __init__(self):
        self.db_config = {
        "host": "localhost",
        "user": "root",  # Change to your MySQL username
        "password": "admin123",  # Change to your MySQL password
        "database": "test_db"  # Change to your database name
    }

        self.logger = self._setup_logger()
    
    def _setup_logger(self):
        """Setup logger for the class"""
        import logging
        logging.basicConfig(level=logging.INFO)
        return logging.getLogger(__name__)
    
    def get_db_connection(self):
        """Get MySQL database connection"""
        try:
            import mysql
            conn = mysql.connector.connect(**self.db_config)
            return conn
        except mysql.connector.Error as e:
            self.logger.error(f"Database connection failed: {e}")
            raise
    
    def init_database(self):
        """Initialize database and create sample tables"""
        try:
            conn = self.get_db_connection()
            cursor = conn.cursor()
            
            # Create sample users table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    email VARCHAR(100) UNIQUE NOT NULL,
                    age INT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Create sample products table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS products (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    price DECIMAL(10,2),
                    category VARCHAR(50),
                    stock INT DEFAULT 0
                )
            ''')
            
            conn.commit()
            cursor.close()
            conn.close()
            self.logger.info("Database initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Database initialization failed: {e}")
            raise
    
    def create_table(self, table_name: str, schema: str) -> str:
        """Create a new table in the database"""
        try:
            conn = self.get_db_connection()
            cursor = conn.cursor()
            
            # Construct CREATE TABLE query
            query = f"CREATE TABLE IF NOT EXISTS {table_name} ({schema})"
            cursor.execute(query)
            
            conn.commit()
            cursor.close()
            conn.close()
            
            self.logger.info(f"Table '{table_name}' created successfully")
            return f" Table '{table_name}' created successfully"
            
        except Exception as e:
            self.logger.error(f"Error creating table: {e}")
            return f" Failed to create table: {str(e)}"
    
    def read_table(self, table_name: str, limit: int = 10, where_clause: str = None) -> str:
        """Read data from a table"""
        try:
            conn = self.get_db_connection()
            cursor = conn.cursor(dictionary=True)
            
            # Construct SELECT query
            query = f"SELECT * FROM {table_name}"
            if where_clause:
                query += f" WHERE {where_clause}"
            query += f" LIMIT {limit}"
            
            cursor.execute(query)
            rows = cursor.fetchall()
            
            cursor.close()
            conn.close()
            
            # Convert datetime objects to strings for JSON serialization
            for row in rows:
                for key, value in row.items():
                    if hasattr(value, 'isoformat'):
                        row[key] = value.isoformat()
                    elif isinstance(value, float):
                        row[key] = float(value)
            
            self.logger.info(f"Retrieved {len(rows)} rows from '{table_name}'")
            return f" Retrieved {len(rows)} rows from '{table_name}':\n{json.dumps(rows, indent=2)}"
            
        except Exception as e:
            self.logger.error(f"Error reading table: {e}")
            return f" Failed to read table: {str(e)}"
    
    def update_table(self, table_name: str, set_clause: str, where_clause: str) -> str:
        """Update data in a table"""
        try:
            conn = self.get_db_connection()
            cursor = conn.cursor()
            
            # Construct UPDATE query
            query = f"UPDATE {table_name} SET {set_clause} WHERE {where_clause}"
            cursor.execute(query)
            
            rows_affected = cursor.rowcount
            conn.commit()
            cursor.close()
            conn.close()
            
            self.logger.info(f"Updated {rows_affected} rows in '{table_name}'")
            return f" Updated {rows_affected} rows in '{table_name}'"
            
        except Exception as e:
            self.logger.error(f"Error updating table: {e}")
            return f" Failed to update table: {str(e)}"
    
    def delete_table(self, table_name: str, where_clause: str = None) -> str:
        """Delete data from a table or drop the entire table"""
        try:
            conn = self.get_db_connection()
            cursor = conn.cursor()
            
            if where_clause:
                # Delete specific rows
                query = f"DELETE FROM {table_name} WHERE {where_clause}"
                cursor.execute(query)
                rows_affected = cursor.rowcount
                conn.commit()
                
                result = f" Deleted {rows_affected} rows from '{table_name}'"
                self.logger.info(f"Deleted {rows_affected} rows from '{table_name}'")
            else:
                # Drop entire table
                query = f"DROP TABLE IF EXISTS {table_name}"
                cursor.execute(query)
                conn.commit()
                
                result = f" Table '{table_name}' dropped successfully"
                self.logger.info(f"Table '{table_name}' dropped")
            
            cursor.close()
            conn.close()
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error deleting from table: {e}")
            return f" Failed to delete from table: {str(e)}"
    
    def insert_data(self, table_name: str, columns: str, values: str) -> str:
        """Insert data into a table"""
        try:
            conn = self.get_db_connection()
            cursor = conn.cursor()
            
            query = f"INSERT INTO {table_name} ({columns}) VALUES ({values})"
            cursor.execute(query)
            
            row_id = cursor.lastrowid
            conn.commit()
            cursor.close()
            conn.close()
            
            self.logger.info(f"Inserted data into '{table_name}' with ID: {row_id}")
            return f" Data inserted into '{table_name}' with ID: {row_id}"
            
        except Exception as e:
            self.logger.error(f"Error inserting data: {e}")
            return f" Failed to insert data: {str(e)}"
    
    def show_tables(self) -> str:
        """Show all tables in the database"""
        try:
            conn = self.get_db_connection()
            cursor = conn.cursor()
            
            cursor.execute("SHOW TABLES")
            tables = cursor.fetchall()
            
            cursor.close()
            conn.close()
            
            table_list = [table[0] for table in tables]
            return f"📋 Tables in database: {table_list}"
            
        except Exception as e:
            self.logger.error(f"Error showing tables: {e}")
            return f" Failed to show tables: {str(e)}"
    
    def describe_table(self, table_name: str) -> str:
        """Describe the structure of a table"""
        try:
            conn = self.get_db_connection()
            cursor = conn.cursor(dictionary=True)
            
            cursor.execute(f"DESCRIBE {table_name}")
            structure = cursor.fetchall()
            
            cursor.close()
            conn.close()
            
            return f"📋 Structure of '{table_name}':\n{json.dumps(structure, indent=2)}"
            
        except Exception as e:
            self.logger.error(f"Error describing table: {e}")
            return f" Failed to describe table: {str(e)}"
    
    def execute_query(self, query: str) -> str:
        """Execute a custom SQL query (SELECT only for safety)"""
        try:
            # Safety check - only allow SELECT queries
            if not query.strip().upper().startswith('SELECT'):
                return " Only SELECT queries are allowed for safety"
            
            conn = self.get_db_connection()
            cursor = conn.cursor(dictionary=True)
            
            cursor.execute(query)
            results = cursor.fetchall()
            
            cursor.close()
            conn.close()
            
            # Handle datetime serialization
            for row in results:
                for key, value in row.items():
                    if hasattr(value, 'isoformat'):
                        row[key] = value.isoformat()
                    elif isinstance(value, float):
                        row[key] = float(value)
            
            self.logger.info(f"Query executed successfully, returned {len(results)} rows")
            return f" Query results ({len(results)} rows):\n{json.dumps(results, indent=2)}"
            
        except Exception as e:
            self.logger.error(f"Error executing query: {e}")
            return f" Query failed: {str(e)}"
    
    def test_connection(self) -> str:
        """Test database connection"""
        try:
            conn = self.get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            result = cursor.fetchone()
            cursor.close()
            conn.close()
            
            return f"Database connection successful! Test query returned: {result[0]}"
        except Exception as e:
            return f" Database connection failed: {str(e)}"


# Create global instance of the database manager
db_manager = MySQLCRUDManager()

# Create FastMCP instance
mcp = FastMCP("SQL CRUD")

# MCP Tools - these call the class methods
@mcp.tool()
async def create_table(table_name: str, schema: str) -> str:
    """
    Create a new table in the database
    
    Args:
        table_name: Name of the table to create
        schema: SQL schema definition (e.g., "id INT PRIMARY KEY, name VARCHAR(100)")
    
    Returns:
        Success or error message
    """
    global db_manager

    return db_manager.create_table(table_name, schema)

@mcp.tool()
async def read_table(table_name: str, limit: int = 10, where_clause: str = None) -> str:
    """
    Read data from a table
    
    Args:
        table_name: Name of the table to read from
        limit: Maximum number of rows to return
        where_clause: Optional WHERE condition (e.g., "age > 18")
    
    Returns:
        Table data in JSON format
    """
    global db_manager
    return db_manager.read_table(table_name, limit, where_clause)

@mcp.tool()
async def update_table(table_name: str, set_clause: str, where_clause: str) -> str:
    """
    Update data in a table
    
    Args:
        table_name: Name of the table to update
        set_clause: SET clause (e.g., "name = 'John', age = 30")
        where_clause: WHERE condition (e.g., "id = 1")
    
    Returns:
        Success message with number of affected rows
    """
    global db_manager
    return db_manager.update_table(table_name, set_clause, where_clause)

@mcp.tool()
async def delete_table(table_name: str, where_clause: str = None) -> str:
    """
    Delete data from a table or drop the entire table
    
    Args:
        table_name: Name of the table
        where_clause: WHERE condition for deleting rows. If None, drops the entire table
    
    Returns:
        Success message with number of affected rows or table drop confirmation
    """
    global db_manager
    return db_manager.delete_table(table_name, where_clause)

@mcp.tool()
async def insert_data(table_name: str, columns: str, values: str) -> str:
    """
    Insert data into a table
    
    Args:
        table_name: Name of the table
        columns: Column names (e.g., "name, email, age")
        values: Values to insert (e.g., "'John', 'john@email.com', 25")
    
    Returns:
        Success message with inserted row ID
    """
    global db_manager
    return db_manager.insert_data(table_name, columns, values)

@mcp.tool()
async def show_tables() -> str:
    """
    Show all tables in the database
    
    Returns:
        List of all tables
    """
    global db_manager
    return db_manager.show_tables()

@mcp.tool()
async def describe_table(table_name: str) -> str:
    """
    Describe the structure of a table
    
    Args:
        table_name: Name of the table to describe
    
    Returns:
        Table structure information
    """
    global db_manager
    return db_manager.describe_table(table_name)

@mcp.tool()
async def execute_query(query: str) -> str:
    """
    Execute a custom SQL query (SELECT only for safety)
    
    Args:
        query: SQL query to execute (must start with SELECT)
    
    Returns:
        Query results
    """
    global db_manager
    return db_manager.execute_query(query)

@mcp.tool()
async def test_connection() -> str:
    """Test database connection"""
    global db_manager
    return db_manager.test_connection()

if __name__ == "__main__":
    print("Starting Class-Based MySQL CRUD MCP Server")
    print("=" * 50)
    print("Available tools:")
    print("  - create_table: Create new tables")
    print("  - read_table: Read data from tables")
    print("  - update_table: Update table data")
    print("  - delete_table: Delete data or drop tables")
    print("  - insert_data: Insert new data")
    print("  - show_tables: List all tables")
    print("  - describe_table: Show table structure")
    print("  - execute_query: Run custom SELECT queries")
    print("  - test_connection: Test database connection")
    print("=" * 50)
    
    # Initialize database
    try:
        db_manager.init_database()
        print("Database initialized")
    except Exception as e:
        print(f"Database initialization failed: {e}")
        print("Make sure MySQL server is running and credentials are correct")
    
    # Run the server
    mcp.run(transport="sse")