#!/usr/bin/env python3
"""
FastMCP Weather Server - Get current weather for any city
Fixed version with proper configuration
"""

import asyncio
#import aiohttp
# import logging
import os
from typing import List, Dict
from fastmcp import FastMCP

# Configure logging
# logging.basicConfig(
#     level=logging.INFO,
#     format='%(asctime)s - %(levelname)s - %(message)s'
# )
# logger = logging.getLogger(__name__)

# Create FastMCP instance
mcp = FastMCP("Weather Server")

@mcp.tool()
async def get_weather(city: str) -> str:
    """
    Get current weather conditions for any city.
    
    Args:
        city: City name (e.g., 'London', 'New York', 'Tokyo')
    
    Returns:
        Current weather information including temperature, conditions, humidity, and wind
    """
    #logger.info(f"Weather requested for: {city}")
    result = f"Weather for {city}: 16°C, Nice and sunny! 🌞"
    #logger.info(f"Returning: {result}")
    return result

@mcp.tool()
async def test_tool() -> str:
    """Simple test tool to verify server is working"""
    #logger.info("Test tool called")
    return "✅ Test successful! Server is working properly."

if __name__ == "__main__":
    # Proper configuration for Colab + ngrok
   # logger.info("Available tools: get_weather, test_tool")
    
    # Run with proper host and port configuration
    mcp.run(transport="sse")